#ifndef FUNCS_H
#define FUNCS_H
#include <string>
#include "Structs.h"
using namespace std;

string toLowerStr(const string &s);
bool isNumberString(const string &s);
double getDoubleInput(const string &prompt);
int getIntInput(const string &prompt);
string getLineInputNonEmpty(const string &prompt);
void saveBudgetsToFile();
void loadBudgetsFromFile();
void saveRequestsToFile();
void loadRequestsFromFile();
void saveAccountsToFile();
void loadAccountsFromFile();
void saveProfilesToFile();
void loadProfilesFromFile();
double computeTotalIncome();
double computeTotalExpense();
void drawHeaderBox(const string &title);
void showAllBudgetsFancy();
void addBudgetInteractive(const string &owner);
int findBudgetIndexById(int id);
void editBudgetInteractive(const string &currentUser, bool isParentOrAdult);
void deleteBudgetInteractive(const string &currentUser, bool isParentOrAdult);
void searchBudgetsMenu();
void sortBudgetsMenu();
void showSummary();
void createAccount();
Account* loginAccount();
Profile* findProfileByUsername(const string &uname);
void submitRequest(const Account &acc);
void parentProcessRequests();
void manageProfiles();
void manageAccounts();
void parentMenu(Account &acc);
void childMenu(Account &acc);
void bootstrapDefaultsIfEmpty();

#endif 
