#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <algorithm>

#include "Funcs.h"
#include "Structs.h"
#include "globals.h"
using namespace std;

double computeTotalIncome() {
    double s = 0.0;
    for (int i = 0; i < budgetCount; ++i) if (toLowerStr(budgets[i].type) == "income") s += budgets[i].amount;
    return s;
}

double computeTotalExpense() {
    double s = 0.0;
    for (int i = 0; i < budgetCount; ++i) if (toLowerStr(budgets[i].type) == "expense") s += budgets[i].amount;
    return s;
}

void drawHeaderBox(const string &title) {
    int width = 60;
    cout << "\n+" << string(width, '=') << "+\n";
    int padding = (width - (int)title.size()) / 2;
    cout << "|" << string(padding, ' ') << title << string(width - padding - (int)title.size(), ' ') << "|\n";
    cout << "+" << string(width, '=') << "+\n";
}

void showAllBudgetsFancy() {
    if (budgetCount == 0) {
        cout << "\nNo budget records available.\n";
        return;
    }
    cout << "\n+--------------------------------------------------------------------------------+\n";
    cout << "|  ID | Name                          |     Amount | Type       | Owner          |\n";
    cout << "+--------------------------------------------------------------------------------+\n";
    for (int i = 0; i < budgetCount; ++i) {
        cout << "| " << setw(3) << budgets[i].id << " | " << left << setw(28) << budgets[i].name << right << " | "
             << setw(10) << fixed << setprecision(2) << budgets[i].amount << " | " << setw(10) << budgets[i].type << " | " << setw(13) << budgets[i].owner << " |\n";
    }
    cout << "+--------------------------------------------------------------------------------+\n";
    cout << "Total Income : " << fixed << setprecision(2) << computeTotalIncome() << "     Total Expense: " << fixed << setprecision(2) << computeTotalExpense() << "     Balance: " << fixed << setprecision(2) << (computeTotalIncome() - computeTotalExpense()) << "\n";
}

